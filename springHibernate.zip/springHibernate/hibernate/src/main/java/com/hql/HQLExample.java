package com.hql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.spring.hibernate.Student;

public class HQLExample {
public static void main(String[] args) {
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
	
	Session s= factory.openSession();
	
	  //creating Student object 
    Student2 st1= new Student2();
    st1.setId(101);
    st1.setName("Saurabh");
    st1.setCity("Pune");
    System.out.println(st1);
    
    Student2 st2= new Student2();
    st2.setId(102);
    st2.setName("Ashita");
    st2.setCity("Bengal");
    System.out.println(st1);
    
   
    Transaction tx= s.beginTransaction();
    s.save(st1); 
    s.save(st2);
    tx.commit();
	//HQL
	//Syntax
	
    String query="from Student2 where city='Bengal'";
	Query q=s.createQuery(query);
	
	//single result -Unique
	//multiple result-list
	List<Student2> list=q.list();
	
	for(Student2 student:list) {
		System.out.println(student.getName()+" "+ student.getId());
	}
	
	s.close();
}
}
