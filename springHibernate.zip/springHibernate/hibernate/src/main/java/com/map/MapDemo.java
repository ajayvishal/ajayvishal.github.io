package com.map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapDemo {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

		// creating Question object

		Question q1 = new Question();
		q1.setQuestionId(1212);
		q1.setQuestion("What is Java");

		// creating answer object
		Answer ans1 = new Answer();
		ans1.setAnswerId(343);
		ans1.setAnswer("Jave is programming language");
		q1.setAnswer(ans1);
		
		// creating Question object

				Question q2 = new Question();
				q2.setQuestionId(242);
				q2.setQuestion("What is Collection framewrok");

				// creating answer object
				Answer ans2 = new Answer();
				ans2.setAnswerId(344);
				ans2.setAnswer("API to work with objects in java");
				q2.setAnswer(ans2);

		// session
		Session s = factory.openSession();
		Transaction tx = s.beginTransaction();

		//save
		s.save(q1);
		s.save(q2);
		s.save(ans1);
		s.save(ans2);
		
		//fetch data
//		
//		Question que1=(Question)s.get(Question.class,242 );
//		System.out.println(que1.getQuestion());
//		System.out.println(que1.getAnswer().getAnswer());
		
		tx.commit();

		factory.close();

	}

}
