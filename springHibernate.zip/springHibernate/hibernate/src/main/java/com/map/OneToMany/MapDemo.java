package com.map.OneToMany;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MapDemo {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("com/map/OneToMany/hibernate1.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();

//		// creating Question object
//
//		Question q1 = new Question();
//		q1.setQuestionId(1212);
//		q1.setQuestion("What is Java");
//
//		// creating answer 1 object
//		Answer ans1 = new Answer();
//		ans1.setAnswerId(343);
//		ans1.setAnswer("Jave is programming language");
//		ans1.setQuestions(q1);
//		
//		//creating answer 2
//		
//		Answer ans2 = new Answer();
//		ans2.setAnswerId(33);
//		ans2.setAnswer("With help of Jave create Software");
//		ans2.setQuestions(q1);
//		
//		//creating answer 3
//		Answer ans3 = new Answer();
//		ans3.setAnswerId(363);
//		ans3.setAnswer("Jave has different types of framewroks");
//		ans3.setQuestions(q1);
//		
//		List<Answer> list = new ArrayList<Answer>();
//		list.add(ans1);
//		list.add(ans2);
//		list.add(ans3);
//		
//		q1.setAnswers(list);
//		


		// session
		Session s = factory.openSession();
		Transaction tx = s.beginTransaction();

//		//save
//		s.save(q1);
//		s.save(ans1);
//		s.save(ans2);
//		s.save(ans3);
		
		//fetch data
//		
		Question q=(Question)s.get(Question.class,1212 );
		System.out.println(q.getQuestionId());
		System.out.println(q.getQuestion());
		
	
		
		
		
		
		
		tx.commit();

		factory.close();

	}

}
