package com.States;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StateDemo {

	public static void main(String[] args) {
		// Transient
		//Persistence
		//Detached
		//Removed
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		//creating Student object
		Student s1=new Student();
		s1.setId(12);
		s1.setName("Saurabh");
		s1.setCity("Gorakhpur");
		//Student object is in Transient state
		
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session.save(s1);               //Persistence - Object present in Session and Database 
		
		s1.setName("Ayush");
		
		tx.commit();
		
		session.close();
		
		//detached state
		s1.setName("Vishal");
		System.out.println(s1);
		factory.close();
	}

}
