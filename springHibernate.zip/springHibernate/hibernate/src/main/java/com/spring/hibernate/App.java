package com.spring.hibernate;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class App 
{
    public static void main( String[] args ) throws IOException
    {
        System.out.println( "project started" );
        
        //making object of child class of SessionFact
// SessionFactory factory=new Configuration().configure().buildSessionFactory();
        
      Configuration cfg = new Configuration();
      cfg.configure("hibernate.cfg.xml");
      SessionFactory factory = cfg.buildSessionFactory(); 
        
      //creating Student object 
      Student st= new Student();
      st.setId(101);
      st.setName("Saurabh");
      st.setCity("Pune");
      System.out.println(st);
      
      Student st1= new Student();
      st.setId(102);
      st.setName("Ashita");
      st.setCity("Bengal");
      System.out.println(st1);
      
      //creating object of Address class
      
      Address ad=new Address();
      ad.setCity("Stavanger");
      ad.setStreet("oslo");
      ad.setOpen(true);
      ad.setAddedDate(new Date());    
      ad.setAddressId(88);
      
      //reading image
//      FileInputStream fis= new FileInputStream("src/main/java/saurabh");
//     byte[] data=new byte[fis.available()];
//     fis.read(data);
//     ad.setImage(data);
     
       
       Session session = factory.openSession();
       Transaction tx= session.beginTransaction();
       session.save(st); 
       session.save(ad);
       tx.commit();
       
       session.close();
        
    }
}
