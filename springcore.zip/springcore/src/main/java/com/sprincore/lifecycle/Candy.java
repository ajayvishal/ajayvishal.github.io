package com.sprincore.lifecycle;

public class Candy {
private double price;

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	System.out.println("setting price");
	this.price = price;
}

public Candy() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Candy [price=" + price + "]";
}
public void init() {
	System.out.println("Inside Init method");
}
public void destroy() {
	System.out.println("Inside destroy method");
}
}
