package com.sprincore.lifecycle;

public class Coldrink {
private double price;

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public Coldrink() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public String toString() {
	return "Coldrink [price=" + price + "]";
}

}
