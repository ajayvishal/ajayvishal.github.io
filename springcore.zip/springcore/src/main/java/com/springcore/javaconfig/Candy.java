package com.springcore.javaconfig;

public class Candy {
	public void display() {
	System.out.println("My price is high");
	}
}
