package com.springcore.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;


public class Student {
	
	private Candy candy;
	
	
	public Student(Candy candy) {
		super();
		this.candy = candy;
	}


	public Candy getCandy() {
		return candy;
	}


	public void setCandy(Candy candy) {
		this.candy = candy;
	}


	public void study() {
		
		this.candy.display();
		System.out.println("Student is reading book");
	}

}
