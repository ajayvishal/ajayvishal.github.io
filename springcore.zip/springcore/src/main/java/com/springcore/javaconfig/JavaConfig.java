package com.springcore.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration

public class JavaConfig {

	@Bean
	public Candy getCandy() {
		
		return new Candy();
	}
	
	@Bean
	public Student getStudent() {
		
		//creating new student object
		Student student=new Student(getCandy());
		return student;
		
	}
	
}
