USE xyz;
CREATE TABLE department (
dep_id BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
dep_address VARCHAR(50),
dep_city VARCHAR(30),
dep_pincode INT(8),
dep_contact_number INT(12)
);

ALTER TABLE employee
ADD COLUMN em_department_id BIGINT(20);

ALTER TABLE employee
ADD CONSTRAINT em_de_fk
FOREIGN KEY (em_department_id) REFERENCES department(dep_id);

DESCRIBE employee;