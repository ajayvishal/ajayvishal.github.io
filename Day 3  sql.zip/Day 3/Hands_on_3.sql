USE schemadb;
SELECT name, length(name) as length FROM user 
ORDER BY name;