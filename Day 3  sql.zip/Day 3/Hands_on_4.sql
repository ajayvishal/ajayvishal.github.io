USE schemadb;
SELECT name FROM user
WHERE name LIKE 'a%a';