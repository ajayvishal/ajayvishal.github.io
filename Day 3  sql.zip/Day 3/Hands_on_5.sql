CREATE DATABASE xyz;
USE xyz;
CREATE TABLE employee(
em_id BIGINT(20) AUTO_INCREMENT PRIMARY KEY,
em_frist_name VARCHAR(30) ,
em_last_name VARCHAR(30) ,
em_date_of_birth DATE,
em_salary BIGINT(20),
em_department_name VARCHAR(30)
);
SELECT * FROM employee;
