USE schemadb;

SELECT content FROM query
WHERE user_id IN 
(SELECT id FROM user
WHERE name = 'ram')
ORDER BY date;