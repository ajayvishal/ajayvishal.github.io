package com.spring.jdbc;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "My Program starts now" );
        
        //Spring Jdbc template
        ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
      StudentDao studentDao = context.getBean("studentDao",StudentDao.class);
     
      //Insert
      Student student = new Student();
      student.setId(123);
      student.setName("Anshul");
      student.setCity("Kanpur");
      
       int result=studentDao.insert(student); 
       System.out.println("result added"+ result);
      
//     Update  
//      Student student=new Student();
//      student.setId(333);
//      student.setName("shivani");
//      student.setCity("kolkata");
//      
//      int result=studentDao.change(student); 
//   System.out.println("data changed "+ result);
      
      //Delete 
//      System.out.println("enter the id to be deleted");
//      Scanner sc=new Scanner(System.in);   
//      int n=sc.nextInt();   //  taking user input which id to be deleted
//     
//      int result=studentDao.delete(n);
//      System.out.println("deleted"+ result);
//      
      
    }
}
