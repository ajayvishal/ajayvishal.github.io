use traindb;
select * from station;
select * from train;
select * from schedule;
select * from booking;

INSERT INTO station (st_name, st_city) VALUES ('Vijayawada Main', 'Vijayawada'), ('MGR Chennai Central', 'Chennai'), ('Hyderabad Main', 'Hyderabad');

INSERT INTO train (tr_name, tr_origin, tr_destination) VALUES ('Pinakini SF Express', 1, 2), ('Charminar SF Express', 2, 3);


INSERT INTO schedule (sc_arrival_time, sc_departure_time, sc_no_of_days, sc_tr_id, sc_st_id) VALUES ('2020-01-16 14:00:00', '2020-01-16 15:00:00', 1, 1, 1), ('2020-01-16 17:10:00', '2020-01-16 18:10:00', 1, 2, 2);

INSERT INTO booking (bk_booking_date, bk_pnr, bk_no_of_pass, bk_tr_id, bk_st_id) VALUES ('2020-01-05 19:00:00', 345678, 4, 2, 2), ('2020-01-10 22:05:55', 946789, 5, 1, 1);