CREATE DATABASE library;
USE library;

CREATE TABLE book (
id BIGINT(20) AUTO_INCREMENT ,
title VARCHAR(50),
author_name VARCHAR(50), 
price INT(10),
publisher VARCHAR(50),
ISBN BIGINT(20),
PRIMARY KEY (id)
);

CREATE TABLE subscriber (
id BIGINT(20) AUTO_INCREMENT,
name VARCHAR(50),
address VARCHAR(50),
contact_number INT(12),
PRIMARY KEY (id)
);

CREATE TABLE book_lending_details (
id BIGINT(20) AUTO_INCREMENT,
subscriber_id BIGINT(20),
book_id BIGINT(20),
date_of_lending DATETIME,
PRIMARY KEY (id),
FOREIGN KEY (subscriber_id) REFERENCES subscriber(id) ON DELETE CASCADE,
FOREIGN KEY (book_id) REFERENCES book(id) ON DELETE CASCADE
); 



