CREATE DATABASE train_ticket_booking;
USE train_ticket_booking;

DROP TABLE station;
DROP TABLE train;
DROP TABLE schedule;
DROP TABLE booking;

CREATE TABLE station (
st_id BIGINT(6) AUTO_INCREMENT PRIMARY KEY,
st_name VARCHAR(45) UNIQUE,
st_city VARCHAR(45)
);

CREATE TABLE train (
tr_id BIGINT(6) AUTO_INCREMENT PRIMARY KEY,
tr_name VARCHAR(45) UNIQUE,
tr_origin VARCHAR(45),
tr_destination VARCHAR(45)
);

CREATE TABLE schedule (
sc_id BIGINT(6) AUTO_INCREMENT PRIMARY KEY,
sc_arrival_time DATETIME,
sc_departure_time DATETIME,
sc_no_of_days INT,
sc_tr_name VARCHAR(45),
sc_st_name VARCHAR(45),
CONSTRAINT  fk_sc_tr
FOREIGN KEY (sc_tr_name) REFERENCES train(tr_name) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_sc_st
FOREIGN KEY (sc_st_name) REFERENCES station(st_name) ON DELETE CASCADE ON UPDATE CASCADE 
);

CREATE TABLE booking (
bk_id BIGINT(12) AUTO_INCREMENT PRIMARY KEY,
bk_booking_date DATETIME,
bk_pnr BIGINT(12) UNIQUE,
bk_no_of_passengers INT,
bk_tr_name VARCHAR(45),
bk_st_name VARCHAR(45),
CONSTRAINT fk_bk_tr
FOREIGN KEY (bk_tr_name) REFERENCES train (tr_name) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_bk_st 
FOREIGN KEY (bk_st_name) REFERENCES station (st_name) ON DELETE CASCADE ON UPDATE CASCADE
);


INSERT INTO train (tr_name, tr_origin, tr_destination) VALUES ('Pinakini SF Express', 'Vijayawada', 'Chennai'), ('Charminar SF Express', 'Chennai','Hyderabad');

INSERT INTO station (st_name, st_city) VALUES ('Vijayawada Main', 'Vijayawada'), ('MGR Chennai Central', 'Chennai'), ('Hyderabad Main', 'Hyderabad');

SELECT * FROM train;
SELECT * FROM station;
SELECT * FROM schedule;
SELECT * FROM booking;

INSERT INTO schedule (sc_arrival_time, sc_departure_time, sc_no_of_days, sc_tr_name, sc_st_name) VALUES ('2020-01-16 14:00:00', '2020-01-16 15:00:00', 1, 'Pinakini sf express', 'Vijayawada Main'), ('2020-01-16 17:10:00', '2020-01-16 18:10:00', 1, 'Charminar sf express', 'MGR Chennai Central');

INSERT INTO booking (bk_booking_date, bk_pnr, bk_no_of_passengers, bk_tr_name, bk_st_name) VALUES ('2020-01-05 19:00:00', 345678, 4, 'Charminar SF Express', 'MGR Chennai Central'), ('2020-01-10 22:05:55', 946789, 5, 'Pinakini SF Express', 'Vijayawada Main');